import React, { useMemo, useState } from "react";
import { Button } from "./ui";
import { ACTIVITIES } from "../data/activities";

export function StepActivity({ value, onChange, onNext, onBack }: any) {
  const [query, setQuery] = useState(value || "");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selected, setSelected] = useState<any>(null);
  const [sectorFilter, setSectorFilter] = useState<any>(null);
  const [subsectorFilter, setSubsectorFilter] = useState<any>(null);

  // Search utilities
  // - typo-tolerant: allow very small edit distance (<= 1) on medium/long tokens
  // - not fuzzy-noisy: keep strict thresholds + require decent token length
  function normalizeCompact(str: string) {
    return (str || "").toLowerCase().replace(/[^a-z0-9]/g, "").trim();
  }
  function normalizeSpaced(str: string) {
    return (str || "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }
  function tokens(str: string) {
    return normalizeSpaced(str).split(" ").filter(Boolean);
  }

  // Early-exit Levenshtein distance (bounded)
  function editDistanceMax1(a: string, b: string) {
    if (a === b) return 0;
    const la = a.length;
    const lb = b.length;
    if (Math.abs(la - lb) > 1) return 2;
    // substitution / insertion / deletion check with max 1 edit
    let i = 0;
    let j = 0;
    let edits = 0;
    while (i < la && j < lb) {
      if (a[i] === b[j]) { i++; j++; continue; }
      edits++;
      if (edits > 1) return edits;
      if (la > lb) i++; // deletion
      else if (lb > la) j++; // insertion
      else { i++; j++; } // substitution
    }
    if (i < la || j < lb) edits++;
    return edits;
  }

  const sectors = [...new Set((ACTIVITIES as any).map((a: any) => a.sector))];
  const subsectors = sectorFilter ? [...new Set((ACTIVITIES as any).filter((a: any) => a.sector === sectorFilter).map((a: any) => a.subsector))] : [];

  const filteredActivities = (ACTIVITIES as any).filter((a: any) => {
    if (sectorFilter && a.sector !== sectorFilter) return false;
    if (subsectorFilter && a.subsector !== subsectorFilter) return false;
    return true;
  });

  function score(queryStr: string, item: any) {
    const q = normalizeCompact(queryStr);
    if (!q) return 0;

    const name = normalizeCompact(item.activity_name);
    const sector = normalizeCompact(item.sector);
    const subsector = normalizeCompact(item.subsector);
    const combined = `${name} ${subsector} ${sector}`;

    const qTokens = tokens(queryStr);
    const nameTokens = tokens(item.activity_name);
    const sectorTokens = tokens(item.sector);
    const subsectorTokens = tokens(item.subsector);
    let s = 0;

    if (name === q) return 3000;
    if (name.startsWith(q)) s += 2000;
    if (subsector.startsWith(q)) s += 1200;
    if (sector.startsWith(q)) s += 900;

    qTokens.forEach((tRaw) => {
      const t = normalizeCompact(tRaw);
      if (!t) return;
      if (name.includes(t)) s += 400;
      if (subsector.includes(t)) s += 250;
      if (sector.includes(t)) s += 180;

      // Light typo tolerance: only for tokens length >= 5, and only max 1 edit
      if (t.length >= 5) {
        const nearMatch = (cands: string[]) => cands.some((w) => editDistanceMax1(normalizeCompact(w), t) <= 1);
        if (!name.includes(t) && nearMatch(nameTokens)) s += 140;
        if (!subsector.includes(t) && nearMatch(subsectorTokens)) s += 90;
        if (!sector.includes(t) && nearMatch(sectorTokens)) s += 60;
      }
    });

    if (combined.includes(q)) s += 200;
    return s;
  }

  const suggestions = useMemo(() => {
    const qCompact = normalizeCompact(query);
    if (!qCompact) return [];
    return filteredActivities
      .map((x: any) => ({ x, s: score(query, x) }))
      .filter((r: any) => r.s > 0)
      .sort((a: any, b: any) => b.s - a.s)
      .slice(0, 6)
      .map((r: any) => r.x);
  }, [query, sectorFilter, subsectorFilter]);

  const canProceed = !!selected || (sectorFilter && subsectorFilter);

  return (
    <div className="space-y-10">
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="text-3xl font-semibold text-[#003B5C]">What does your business do?</h2>
        <p className="text-sm text-gray-600 mt-3">Start typing your licensed activity or browse by sector below.</p>
      </div>

      <div className="relative max-w-3xl mx-auto">
        <input
          type="text"
          placeholder="e.g. Software development, Freight forwarding..."
          value={query}
          onChange={(e) => { setQuery(e.target.value); setSelected(null); setShowSuggestions(true); }}
          onFocus={() => setShowSuggestions(true)}
          className="w-full border border-[#E2E8F0] rounded-2xl p-5 text-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-[#0077B6]"
        />

        {showSuggestions && query && (
          <div className="absolute z-20 w-full bg-white border border-[#E2E8F0] rounded-2xl shadow-lg mt-3 max-h-80 overflow-y-auto">
            {suggestions.length > 0 ? (
              suggestions.map((s: any) => (
                <div
                  key={s.activity_id}
                  onClick={() => { setSelected(s); setQuery(s.activity_name); onChange(s); setShowSuggestions(false); }}
                  className="px-5 py-4 cursor-pointer hover:bg-blue-50 transition-all"
                >
                  <div className="text-base font-semibold text-[#003B5C]">{s.activity_name}</div>
                  <div className="text-xs text-gray-600 mt-1">{s.sector} • {s.subsector}</div>
                </div>
              ))
            ) : (
              <div className="px-5 py-4 text-sm text-gray-500">No close matches found</div>
            )}
          </div>
        )}
      </div>

      <div className="text-center text-xs uppercase tracking-wide text-gray-400">Or browse by sector</div>

      <div className="flex flex-wrap justify-center gap-3">
        {sectors.map((s: any) => (
          <button
            key={s}
            onClick={() => { setSectorFilter(s); setSubsectorFilter(null); }}
            className={`px-4 py-2 rounded-full text-sm border transition-all ${sectorFilter === s ? "bg-[#0077B6] text-white border-[#0077B6] shadow-sm" : "border-[#E2E8F0] hover:border-[#0077B6]"}`}
          >
            {s}
          </button>
        ))}
        {sectorFilter && (
          <button onClick={() => { setSectorFilter(null); setSubsectorFilter(null); }} className="px-4 py-2 rounded-full text-sm border border-gray-300 text-gray-600">
            Clear
          </button>
        )}
      </div>

      {subsectors.length > 0 && (
        <div className="flex flex-wrap justify-center gap-3">
          {subsectors.map((ss: any) => (
            <button
              key={ss}
              onClick={() => setSubsectorFilter(ss)}
              className={`px-4 py-2 rounded-full text-sm border transition-all ${subsectorFilter === ss ? "bg-blue-100 border-[#0077B6] text-[#003B5C]" : "border-[#E2E8F0] hover:border-[#0077B6]"}`}
            >
              {ss}
            </button>
          ))}
        </div>
      )}

      {selected && (
        <div className="max-w-2xl mx-auto border border-[#0077B6] rounded-2xl p-6 bg-[#E6F4FA] shadow-sm transition-all">
          <div className="text-xs text-[#0077B6] font-medium uppercase tracking-wide">Selected Activity</div>
          <div className="text-lg font-semibold text-[#003B5C] mt-2">{selected.activity_name}</div>
          <div className="text-sm text-gray-600 mt-1">{selected.sector} • {selected.subsector}</div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-4 sm:justify-between">
        <Button variant="outline" onClick={onBack}>Back</Button>
        <Button
          disabled={!canProceed}
          onClick={() => {
            if (selected) { onNext(); return; }
            if (sectorFilter && subsectorFilter) {
              const fallback = (ACTIVITIES as any).find((a: any) => a.sector === sectorFilter && a.subsector === subsectorFilter);
              if (fallback) { setSelected(fallback); setQuery(fallback.activity_name); onChange(fallback); onNext(); }
            }
          }}
          className="sm:ml-auto"
        >
          Continue
        </Button>
      </div>
    </div>
  );
}
