# Dubai Chambers Advisory Engine UI (Vite)

## Run locally
```bash
npm install
npm run dev
```

## Notes
- UI is in **UI SAFE MODE** (mock resolver for preview)
- Data files included under `/data` (engine JSON, resolver, 21-sector test sheet, project context)
